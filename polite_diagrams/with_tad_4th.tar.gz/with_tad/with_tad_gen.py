'''
Self_energy diagrams without tadpoles

Last updates: MAY-10-2019
'''

###################################
##########Import libraries#########
###################################
#Begin
from random import *
import pickle
from math import *
import numpy as np
from copy import deepcopy
from igraph import *
from Label_self import *
from Hubbard_like_diagram import *
#from Symbolic_multi_AMI_new import *
#End
###################################

M=4
diag_num=35
out=[]
for i in range(1,diag_num+1):
  file_name='m_'+str(M)+'_num_'+str(i)+'.graphml'
  G=load(file_name)
  l = G.ecount()
  reset_g(G,M)
  label_abs_ran(G,M,20,20)
  flag=False
  for j in range(0,l):
    if G.es[j]["Label"]==[0]*(M+1):
      flag=True
      break
  if flag:
    print file_name
    G.save('result_4th_with_tad/'+file_name)
    out.append(i)
print out
print len(out)
  
